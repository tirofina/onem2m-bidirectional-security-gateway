from pathlib import Path
import json
import win32com.client
ROOT=Path(__file__).resolve().parent.parent
path=ROOT/'deliverables'/'oneM2M_양방향_보안게이트웨이_발표자료.pptx'
app=win32com.client.DispatchEx('PowerPoint.Application');pres=None;issues=[];checked=0
try:
    pres=app.Presentations.Open(str(path),ReadOnly=True,Untitled=False,WithWindow=False)
    for si in range(1,pres.Slides.Count+1):
        slide=pres.Slides(si)
        for sh in slide.Shapes:
            if not sh.HasTextFrame or not sh.TextFrame.HasText: continue
            tr=sh.TextFrame2.TextRange;txt=tr.Text.strip()
            if not txt: continue
            checked+=1
            bounds=[float(tr.BoundLeft),float(tr.BoundTop),float(tr.BoundWidth),float(tr.BoundHeight)]
            # Actual Office glyph bounds, with 2pt tolerance for font metrics.
            outside= bounds[0] < sh.Left-2 or bounds[1]<sh.Top-2 or bounds[0]+bounds[2]>sh.Left+sh.Width+2 or bounds[1]+bounds[3]>sh.Top+sh.Height+2
            if outside:issues.append({'slide':si,'shape':sh.Name,'text':txt,'shape_rect':[sh.Left,sh.Top,sh.Width,sh.Height],'text_bounds':bounds})
finally:
    if pres:pres.Close()
    if app.Presentations.Count==0:app.Quit()
report={'method':'PowerPoint COM TextFrame2 rendered text bounds, 2pt tolerance','checked_text_shapes':checked,'issues':issues}
(ROOT/'proposal_work'/'powerpoint_layout_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(report,ensure_ascii=False,indent=2))
