import sys,json,time
from pathlib import Path
import win32com.client
import pypdfium2 as pdfium
from PIL import Image,ImageDraw,ImageFont
ROOT=Path(__file__).resolve().parent.parent
OUT=ROOT/'deliverables';WORK=ROOT/'proposal_work';PREVIEW=WORK/'preview';PREVIEW.mkdir(exist_ok=True)
mode=sys.argv[1] if len(sys.argv)>1 else 'doc'
if mode=='doc':
    path=OUT/'oneM2M_양방향_보안게이트웨이_제안서.docx'
    app=win32com.client.DispatchEx('Word.Application');app.Visible=False;app.DisplayAlerts=0
    d=None
    try:
        d=app.Documents.Open(str(path),ReadOnly=False,AddToRecentFiles=False)
        d.Styles(-20).Font.Name='맑은 고딕';d.Styles(-20).Font.Size=9.5
        d.Styles(-20).ParagraphFormat.SpaceAfter=5
        d.Styles(-20).ParagraphFormat.LineSpacingRule=0
        d.Fields.Update();d.Repaginate()
        for toc in d.TablesOfContents: toc.Update()
        d.Repaginate()
        for toc in d.TablesOfContents: toc.UpdatePageNumbers()
        d.Save();d.ExportAsFixedFormat(str(path.with_suffix('.pdf')),17)
        print('Word pages:',d.ComputeStatistics(2))
    finally:
        if d: d.Close(False)
        app.Quit()
elif mode=='deck':
    path=OUT/'oneM2M_양방향_보안게이트웨이_발표자료.pptx'
    app=win32com.client.DispatchEx('PowerPoint.Application')
    pres=None
    try:
        pres=app.Presentations.Open(str(path),ReadOnly=True,Untitled=False,WithWindow=False)
        pres.SaveAs(str(path.with_suffix('.pdf')),32)
        # Native exports for visual review.
        folder=PREVIEW/'slides';folder.mkdir(exist_ok=True)
        for i in range(1,pres.Slides.Count+1):
            pres.Slides(i).Export(str(folder/f'slide-{i:02}.png'),'PNG',1600,900)
        print('PowerPoint slides:',pres.Slides.Count)
    finally:
        if pres: pres.Close()
        if app.Presentations.Count==0: app.Quit()
else:
    raise SystemExit(mode)

pdf=pdfium.PdfDocument(str(path.with_suffix('.pdf')))
texts=[];thumbs=[]
for i in range(len(pdf)):
    p=pdf[i];texts.append(p.get_textpage().get_text_range())
    image=p.render(scale=1.3).to_pil().convert('RGB')
    image.save(PREVIEW/f'{mode}-{i+1:02}.png')
    image.thumbnail((430,580) if mode=='doc' else (600,338))
    thumbs.append(image)
(WORK/f'{mode}_rendered_text.json').write_text(json.dumps(texts,ensure_ascii=False,indent=2),encoding='utf-8')
font=ImageFont.truetype('C:/Windows/Fonts/malgun.ttf',18)
cols=3;count=9 if mode=='doc' else 12;cw=450 if mode=='doc' else 620;ch=620 if mode=='doc' else 380
for start in range(0,len(thumbs),count):
    subset=thumbs[start:start+count];rows=(len(subset)+cols-1)//cols
    sheet=Image.new('RGB',(cols*cw,rows*ch),'#DBE2E8');draw=ImageDraw.Draw(sheet)
    for j,im in enumerate(subset):
        x=(j%cols)*cw+(cw-im.width)//2;y=(j//cols)*ch+30
        sheet.paste(im,(x,y));draw.text(((j%cols)*cw+12,(j//cols)*ch+5),f'{mode} {start+j+1:02}',font=font,fill='#142B45')
    sheet.save(PREVIEW/f'{mode}-contact-{start//count+1}.jpg',quality=90)
print('Rendered',len(pdf),'pages')
