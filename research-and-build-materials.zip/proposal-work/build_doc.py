from pathlib import Path
import math, json
from PIL import Image, ImageDraw, ImageFont
from docx import Document
from docx.shared import Inches, Pt, Cm, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.opc.constants import RELATIONSHIP_TYPE as RT
from content import *

OUT.mkdir(exist_ok=True)
WORK=ROOT/'proposal_work'
NAVY='142B45'; TEAL='00897B'; GOLD='E7B34B'; GRAY='536477'; LIGHT='F0F5F8'; WHITE='FFFFFF'
FONT='맑은 고딕'

def set_font(run,size=None,bold=None,color=None):
    run.font.name=FONT
    run._element.get_or_add_rPr().rFonts.set(qn('w:eastAsia'),FONT)
    if size: run.font.size=Pt(size)
    if bold is not None: run.bold=bold
    if color: run.font.color.rgb=RGBColor.from_string(color)

def shade(cell,fill):
    pr=cell._tc.get_or_add_tcPr(); el=OxmlElement('w:shd'); el.set(qn('w:fill'),fill);pr.append(el)

def margins_cell(cell,top=95,start=110,bottom=95,end=110):
    pr=cell._tc.get_or_add_tcPr();mar=OxmlElement('w:tcMar')
    for tag,val in [('top',top),('start',start),('bottom',bottom),('end',end)]:
        x=OxmlElement('w:'+tag);x.set(qn('w:w'),str(val));x.set(qn('w:type'),'dxa');mar.append(x)
    pr.append(mar)

def no_split(row):
    pr=row._tr.get_or_add_trPr();el=OxmlElement('w:cantSplit');pr.append(el)

def para(text,style=None,size=None,color=None,bold=None):
    p=doc.add_paragraph(style=style)
    r=p.add_run(text);set_font(r,size,bold,color)
    return p

def hyperlink(p,label,url):
    part=p.part;rid=part.relate_to(url,RT.HYPERLINK,is_external=True)
    h=OxmlElement('w:hyperlink');h.set(qn('r:id'),rid)
    r=OxmlElement('w:r');pr=OxmlElement('w:rPr')
    c=OxmlElement('w:color');c.set(qn('w:val'),TEAL);pr.append(c)
    f=OxmlElement('w:rFonts');f.set(qn('w:ascii'),FONT);f.set(qn('w:eastAsia'),FONT);pr.append(f)
    s=OxmlElement('w:sz');s.set(qn('w:val'),'18');pr.append(s)
    r.append(pr);t=OxmlElement('w:t');t.text=label;r.append(t);h.append(r);p._p.append(h)

def table(block):
    rows=block['rows'];heads=block['headers'];widths=block.get('widths') or [1/len(heads)]*len(heads)
    t=doc.add_table(rows=1,cols=len(heads));t.alignment=WD_TABLE_ALIGNMENT.CENTER;t.autofit=False
    total=7.0
    for col,w in zip(t.columns,widths): col.width=Inches(total*w)
    for i,h in enumerate(heads):
        c=t.rows[0].cells[i];c.width=Inches(total*widths[i]);shade(c,NAVY);margins_cell(c)
        p=c.paragraphs[0];p.paragraph_format.space_after=Pt(0);p.paragraph_format.space_before=Pt(0)
        p.paragraph_format.line_spacing=1.05
        set_font(p.add_run(h),9.6,True,WHITE)
    header=OxmlElement('w:tblHeader');t.rows[0]._tr.get_or_add_trPr().append(header)
    for ri,row in enumerate(rows):
        r=t.add_row();no_split(r)
        for i,txt in enumerate(row):
            c=r.cells[i];c.width=Inches(total*widths[i]);c.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
            margins_cell(c);shade(c,LIGHT if ri%2==0 else WHITE)
            p=c.paragraphs[0];p.paragraph_format.space_after=Pt(0);p.paragraph_format.space_before=Pt(0)
            p.paragraph_format.line_spacing=1.1
            set_font(p.add_run(txt),9.4,i==0,NAVY if i==0 else '27384B')
    p=doc.add_paragraph();p.paragraph_format.space_after=Pt(2);p.paragraph_format.space_before=Pt(0);p.paragraph_format.line_spacing=0.1
    set_font(p.add_run(''),2)

def callout(title,text):
    t=doc.add_table(rows=1,cols=1);c=t.cell(0,0);shade(c,'EAF5F2');margins_cell(c,160,180,160,180)
    no_split(t.rows[0])
    p=c.paragraphs[0];p.paragraph_format.space_after=Pt(4);p.paragraph_format.line_spacing=1.1
    set_font(p.add_run(title),10.1,True,TEAL)
    p=c.add_paragraph();p.paragraph_format.space_after=Pt(0);p.paragraph_format.line_spacing=1.15
    set_font(p.add_run(text),9.7,False,NAVY)
    p=doc.add_paragraph();p.paragraph_format.space_after=Pt(0);p.paragraph_format.line_spacing=0.15

def make_arch():
    im=Image.new('RGB',(1800,630),'#FFFFFF');d=ImageDraw.Draw(im)
    reg='C:/Windows/Fonts/malgun.ttf';bold='C:/Windows/Fonts/malgunbd.ttf'
    def txt(x,y,text,size=30,color='#142B45',b=False,center=False):
        f=ImageFont.truetype(bold if b else reg,size)
        for j,line in enumerate(text.split('\n')):
            w=d.textlength(line,font=f);d.text((x-w/2 if center else x,y+j*(size+10)),line,font=f,fill=color)
    def box(x,y,w,h,title,sub,color='#142B45'):
        d.rounded_rectangle((x,y,x+w,y+h),radius=20,fill='#F0F5F8',outline=color,width=3)
        txt(x+w/2,y+24,title,31,color,True,True);txt(x+w/2,y+84,sub,25,'#536477',False,True)
    def arrow(x1,y1,x2,y2,c='#00897B',both=False):
        d.line((x1,y1,x2,y2),fill=c,width=7)
        a=math.atan2(y2-y1,x2-x1)
        for x,y,ang in [(x2,y2,a)]+([(x1,y1,a+math.pi)] if both else []):
            d.polygon([(x,y),(x-22*math.cos(ang-.5),y-22*math.sin(ang-.5)),(x-22*math.cos(ang+.5),y-22*math.sin(ang+.5))],fill=c)
    box(20,155,340,220,'IoT 장치 / 모형','센서 · 제어기\n현장 실행 가드')
    box(445,155,340,220,'네트워크 관문','구간 분리 · IPS\n허용 목적지 제어')
    box(870,155,420,220,'Mobius4 + 정책 집행','인증 주체 · ACP\n자원 의미 · 신뢰 · 상태','#00897B')
    box(1375,155,400,220,'서버 / 제어 앱','수집 · 업무 판단\n명령 생성')
    arrow(366,268,436,268,both=True);arrow(794,268,860,268,both=True);arrow(1298,268,1367,268,both=True)
    txt(900,42,'상향 데이터의 신뢰를 하향 실행 조건에 연결',33,'#00897B',True,True)
    d.rounded_rectangle((447,453,1370,582),radius=16,fill='#142B45')
    txt(905,475,'정책 관리 · 사건 상관관계 · 감사 · 관리자 알림',30,'#FFFFFF',True,True)
    txt(905,526,'정책 버전 배포 / 판단 근거와 실행 결과 수집',25,'#C5D7E5',False,True)
    arrow(1080,444,1080,388,both=True)
    p=WORK/'architecture.png';im.save(p);return p

doc=Document();sec=doc.sections[0]
sec.page_width=Cm(21);sec.page_height=Cm(29.7)
sec.top_margin=Cm(1.7);sec.bottom_margin=Cm(1.6);sec.left_margin=Cm(1.6);sec.right_margin=Cm(1.6)
sec.header_distance=Cm(.75);sec.footer_distance=Cm(.75)
styles=doc.styles
for name in ['Normal','Body Text','Heading 1','Heading 2','TOC 1','Caption']:
    if name not in styles: continue
    s=styles[name];s.font.name=FONT;s._element.get_or_add_rPr().rFonts.set(qn('w:eastAsia'),FONT)
styles['Normal'].font.size=Pt(10.2);styles['Normal'].font.color.rgb=RGBColor.from_string('27384B')
styles['Normal'].paragraph_format.line_spacing=1.24;styles['Normal'].paragraph_format.space_after=Pt(8)
styles['Heading 1'].font.size=Pt(23);styles['Heading 1'].font.color.rgb=RGBColor.from_string(NAVY)
styles['Heading 1'].paragraph_format.space_after=Pt(11);styles['Heading 1'].paragraph_format.space_before=Pt(0)
styles['Heading 1'].paragraph_format.keep_with_next=True
styles['Heading 2'].font.size=Pt(12.5);styles['Heading 2'].font.color.rgb=RGBColor.from_string(TEAL)
styles['Heading 2'].paragraph_format.space_before=Pt(7);styles['Heading 2'].paragraph_format.space_after=Pt(5)
styles['Heading 2'].paragraph_format.keep_with_next=True

sec.different_first_page_header_footer=True
h=sec.header.paragraphs[0];h.paragraph_format.space_after=Pt(0)
set_font(h.add_run('PROJECT PROPOSAL  /  oneM2M SAFETY GATEWAY'),8,True,GRAY)
f=sec.footer.paragraphs[0];f.alignment=WD_ALIGN_PARAGRAPH.RIGHT
set_font(f.add_run('2026.09  •  개발 제안 v1.0     |     '),8,False,GRAY)
field=OxmlElement('w:fldSimple');field.set(qn('w:instr'),'PAGE');f._p.append(field)
doc.core_properties.title=TITLE+' 개발 제안서';doc.core_properties.subject=SUBTITLE
doc.core_properties.author='프로젝트 제안팀';doc.core_properties.keywords='oneM2M, Mobius4, IoT, 양방향 보안, 안전 정책'
doc.core_properties.comments='공식자료·코드·특허 예비조사 기반. 계획 수치는 실측 결과와 구분.'

# Cover: typography and a graphic band, all text remains editable.
para('PROJECT PROPOSAL',size=11,color=TEAL,bold=True).paragraph_format.space_before=Pt(30)
p=para('oneM2M\n양방향 보안\n게이트웨이',size=37,color=NAVY,bold=True)
p.paragraph_format.line_spacing=1.04;p.paragraph_format.space_after=Pt(22)
para(SUBTITLE,size=15,color=GRAY).paragraph_format.space_after=Pt(30)
table(T(['공통 허브','안전 정책 서비스','실증 플랫폼'],[['HTTP · MQTT\n상향 / 하향 통신 보호','데이터 신뢰 · 장치 상태\n실행 전 판단과 감사','도어락 / 난방 모형\n비교 실험과 고객 실증']],[.333,.334,.333]))
para('연결의 신뢰를 확인하고\n실행의 안전을 판단하다',size=22,color=TEAL,bold=True).paragraph_format.space_before=Pt(20)
para('Mobius4 기반 기술·사업 개발 제안서',size=12,color=NAVY,bold=True).paragraph_format.space_before=Pt(18)
para('작성 기준  2026년 9월 22일    |    버전  1.0',size=10,color=GRAY)
para('본 문서는 개발 제안 단계의 자료다. 성능·일정·예산·판매 가격은 별도 표시한 계획 가정이며, 구현 완료나 제품 인증을 의미하지 않는다.',size=9,color=GRAY)

doc.add_page_break()
para('READING GUIDE',size=9,color=TEAL,bold=True)
para('제안서 구성',size=26,color=NAVY,bold=True)
para('기술 검토와 사업 검토가 같은 근거를 공유하도록 구성했다. 핵심 제안은 01~04, 구현은 05~11, 시장·특허는 12~16, 실증·추진은 17~21에서 다룬다.',size=10,color=GRAY)
p=doc.add_paragraph();f=OxmlElement('w:fldSimple');f.set(qn('w:instr'),'TOC \\o "1-1" \\h \\z \\u');p._p.append(f)

arch=make_arch()
for item in pages:
    doc.add_page_break()
    para(item['section'],size=9,color=TEAL,bold=True)
    para(item['title'],'Heading 1')
    p=para(item['lead'],size=11,color=GRAY);p.paragraph_format.space_after=Pt(14)
    for b in item['blocks']:
        k=b['kind']
        if k=='p': para(b['text'])
        elif k=='h': para(b['text'],'Heading 2')
        elif k=='bullets':
            for txt in b['items']:
                p=para('•  '+txt);p.paragraph_format.left_indent=Cm(.15);p.paragraph_format.space_after=Pt(6)
        elif k=='table': table(b)
        elif k=='callout': callout(b['title'],b['text'])
        elif k=='diagram':
            doc.add_picture(str(arch),width=Inches(7.0));para('그림 1. 개념 배치도 — 허브를 경유하는 경로와 실제 실행 지점에 집행',size=8.5,color=GRAY)

# Reference URLs are embedded as clickable links, never long broken text.
for ix,group in enumerate([SOURCES[:7],SOURCES[7:13],SOURCES[13:]]):
    doc.add_page_break();para(f'부록 B / 근거 자료 {ix+1}·3',size=9,color=TEAL,bold=True)
    para(['표준·코드·보안 제품','시장·실적·문헌','특허·구현·운영 참고'][ix],'Heading 1')
    para('자료 확인 기준: 2026.09.22. 본문의 [S번호]는 아래 원문과 연결된다. 제품 기능은 공급업체 설명이며, 실제 성능은 별도 검증 대상이다.',size=10,color=GRAY)
    for src in group:
        p=para(f'[{src[0]}] {src[1]}',size=10.5,bold=True,color=NAVY);p.paragraph_format.space_after=Pt(3);p.paragraph_format.keep_with_next=True
        p=para(src[2],size=9.5,color=GRAY);p.paragraph_format.space_after=Pt(2);p.paragraph_format.keep_with_next=True
        p=doc.add_paragraph();p.paragraph_format.space_after=Pt(11)
        for j,url in enumerate(src[3:]):
            if j: p.add_run('   |   ')
            hyperlink(p,'원문 열기' if j==0 else '보조 원문 열기',url)

path=OUT/'oneM2M_양방향_보안게이트웨이_제안서.docx';doc.save(path)
(WORK/'document_manifest.json').write_text(json.dumps({'docx':str(path),'planned_content_pages':len(pages),'source_count':len(SOURCES)},ensure_ascii=False,indent=2),encoding='utf-8')
print(path)
