import json,re,zipfile
from pathlib import Path
from docx import Document
from pptx import Presentation
from content import ROOT,OUT,pages,SOURCES
W=ROOT/'proposal_work'
def norm(t): return re.sub(r'\s+','',t)
doc=Document(OUT/'oneM2M_양방향_보안게이트웨이_제안서.docx')
doc_text='\n'.join(p.text for p in doc.paragraphs)+'\n'+'\n'.join(c.text for t in doc.tables for r in t.rows for c in r.cells)
pdf_texts=json.loads((W/'doc_rendered_text.json').read_text(encoding='utf-8'))
pdf_text='\n'.join(pdf_texts)
expected=[]
for p in pages:
    expected += [p['title'],p['lead']]
    for b in p['blocks']:
        if b['kind'] in ['p','h']: expected.append(b['text'])
        elif b['kind']=='bullets':expected+=b['items']
        elif b['kind']=='callout':expected+=[b['title'],b['text']]
        elif b['kind']=='table':expected+=b['headers']+[x for row in b['rows'] for x in row if x]
missing=[x[:80] for x in expected if norm(x) not in norm(doc_text)]
titles_missing_pdf=[p['title'] for p in pages if norm(p['title']) not in norm(pdf_text)]
assert not missing,missing
assert not titles_missing_pdf,titles_missing_pdf
assert len(pdf_texts)==27,len(pdf_texts)
for x in ['MARKET_','PATENT_','TODO','TBD']:
    assert x not in doc_text,x
assert '1억 560만 원' in doc_text
assert '95%' in doc_text and '0.1%' in doc_text and '46.7%' in doc_text
with zipfile.ZipFile(OUT/'oneM2M_양방향_보안게이트웨이_제안서.docx') as z:
    assert z.testzip() is None
    rels=z.read('word/_rels/document.xml.rels').decode()
    for s in SOURCES:
        for url in s[3:]: assert url.replace('&','&amp;') in rels,url

report={'docx':{'content_items_checked':len(expected),'missing_items':missing,'rendered_pages':len(pdf_texts),'rendered_section_titles':len(pages),'reference_sources':len(SOURCES),'embedded_source_urls_checked':sum(len(s)-3 for s in SOURCES)},'numbers':{'mvp_budget_manwon':8000+600+200+800+960,'year1_revenue_manwon':300+50*12,'year1_cogs_manwon':180+25*12,'year1_gross_margin_percent':round((900-480)/900*100,1)}}
ppt=OUT/'oneM2M_양방향_보안게이트웨이_발표자료.pptx'
if ppt.exists():
    pr=Presentation(ppt);texts=[];over=[];empty_notes=[];count=0
    for i,s in enumerate(pr.slides,1):
        lines=[]
        for sh in s.shapes:
            if sh.has_text_frame: lines.append(sh.text)
            if sh.left<0 or sh.top<0 or sh.left+sh.width>pr.slide_width+10000 or sh.top+sh.height>pr.slide_height+10000:over.append((i,sh.name))
            count+=1
        texts.append('\n'.join(lines))
        if not s.has_notes_slide or not s.notes_slide.notes_text_frame.text.strip():empty_notes.append(i)
    alltext='\n'.join(texts)
    for marker in ['MARKET_','PATENT_','TODO','TBD']: assert marker not in alltext,marker
    assert 20<=len(pr.slides)<=26,len(pr.slides)
    assert not over,over
    assert not empty_notes,empty_notes
    for term in ['oneM2M','Mobius4','Suricata','95%','0.1%','20ms','16주','Verisure','Allegion','Resideo','KR102863685B1']:
        assert term in alltext,term
    with zipfile.ZipFile(ppt) as z: assert z.testzip() is None
    report['pptx']={'slides':len(pr.slides),'native_shapes':count,'out_of_bounds_shapes':over,'empty_notes':empty_notes,'required_key_content_present':True}
(W/'quality_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(report,ensure_ascii=False,indent=2))
